        </div><!--content-->
        <div class="footer">
        	<div class="creator">
        		<a href="http://pupungbp.erastica.com/wordpress-theme/magzine-magazine-style-free-wordpress-theme/"><strong>MagZine</strong></a> theme designed by <a href="http://pupungbp.erastica.com"><em>pupung budi purnama</em></a>
        	</div>
        	<div class="copyright">
        		&copy; 2009 <strong><?php bloginfo('name'); ?></strong> all rights reserved
        	</div>
        </div>
    </div><!--container-->
</div><!--outer-->

<?php wp_footer() ?>
</body>
</html>